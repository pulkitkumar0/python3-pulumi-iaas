# examples/webserver-go

An example in Go based on the basic Amazon EC2 Instance sample at:
http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/deploying.applications.html.
