# examples/stream

A simple example of using the `Stream` APIs.