# examples/topic

A simple example of using the `Topic` APIs.