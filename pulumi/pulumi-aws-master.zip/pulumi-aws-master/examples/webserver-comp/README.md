# examples/webserver-comp

This is an example derived from the webserver example, demonstrating componentization of resources and multi-instancing
of them.  It's still relatively basic but demonstrates the powers of components using a relatively basic example.

