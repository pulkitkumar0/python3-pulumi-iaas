# examples/rename-ses-configuration-set

A simple example of how the ses-configuration-set Tok was managed and the alias persists correctly.