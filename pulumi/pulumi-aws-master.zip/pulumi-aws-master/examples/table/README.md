# examples/table

A simple example of using the `Table` APIs.