# examples/multiple-regions

An example based on the basic Amazon EC2 Instance sample at:
http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/deploying.applications.html.

This example deploys a web server into the us-west-2 and us-east-1 regions.

