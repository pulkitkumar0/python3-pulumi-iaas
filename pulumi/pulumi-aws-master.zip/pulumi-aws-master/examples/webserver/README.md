# examples/webserver

An example based on the basic Amazon EC2 Instance sample at:
http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/deploying.applications.html.

