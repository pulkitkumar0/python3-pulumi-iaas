# WebServer per Availability Zone

A slight variant on the base WebServer example that creates an instance per availability zone.

