# WebServer with SSH

A slight variant on the base WebServer example that adds SSH.

