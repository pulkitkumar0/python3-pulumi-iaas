# WebServer with SSH (and description)

A slight variant on the base WebServer example that adds SSH.  In addition to adding the SSH ingress rule, it
alters the description on the security group, necessitating a "replacement" operation when run as an edit.

