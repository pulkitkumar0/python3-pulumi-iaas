# WebServer with a Get

A slight variant on the base WebServer example that gets the WebServer after creating it.
