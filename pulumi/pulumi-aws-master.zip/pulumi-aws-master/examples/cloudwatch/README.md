# examples/cloudwatch

A simple example of using the `CloudWatch` APIs.