exports.handler = (e, c, cb) => cb(null, {statusCode: 200, body: 'Hello, world!'});
