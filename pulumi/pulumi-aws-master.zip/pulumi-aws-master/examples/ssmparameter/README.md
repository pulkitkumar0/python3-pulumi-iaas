# examples/ssmparameter

A simple example of using SSM Parameters.
