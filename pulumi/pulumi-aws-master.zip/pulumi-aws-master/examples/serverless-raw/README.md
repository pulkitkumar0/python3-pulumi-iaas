# examples/serverless-raw

An example using some serverless AWS resources, currently including:

* AWS Lambda Function
* AWS IAM Role
* AWS DynamoDB Table
* AWS APIGateway RestAPI
