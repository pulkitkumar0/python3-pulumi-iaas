# examples/bucket

A simple example of using the `Bucket` APIs.