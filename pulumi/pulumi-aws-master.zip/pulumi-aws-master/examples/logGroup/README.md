# examples/loggroup

A simple example of using the `LogGroup` APIs.