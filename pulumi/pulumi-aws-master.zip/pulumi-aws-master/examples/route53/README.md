# examples/route53

A simple example of using the `route53` APIs.
