#!/bin/bash
set -exu
cd /server/
exec node index.js
