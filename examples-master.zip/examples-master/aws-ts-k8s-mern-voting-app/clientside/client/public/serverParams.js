// This file will automatically be replaced during docker run, and will contain the URL to the serverside.
window.SERVER_URL = "placeholder";
